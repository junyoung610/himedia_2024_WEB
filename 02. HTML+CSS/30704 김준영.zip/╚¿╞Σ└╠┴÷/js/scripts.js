$('.open-pop').click(function(){
    $('.popup').fadeIn()
})
$('.close-pop').click(function(){
    $('.popup').fadeOut()
})